//
//  MyScrollView.h
//  JigsawPuzzle
//
//  Created by Apple on 13-3-23.
//  Copyright (c) 2013年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyScrollView : UIScrollView

@end
