//
//  MainViewController.h
//  SlideShow
//
//  Created by Apple on 13-5-30.
//  Copyright (c) 2013年 Apple. All rights reserved.
//

#import "FlipsideViewController.h"
#import "MyScrollView.h"
#import <QuartzCore/QuartzCore.h>
#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )

enum PAGE_NUM {
    PAGE_1 = 0,
    PAGE_2,
    PAGE_3,
    PAGE_4,
    PAGE_5,
    PAGE_9_5,
    PAGE_6,
    PAGE_7,
    PAGE_4_5,
    PAGE_9,
    PAGE_10,
    PAGE_COUNT
};
@interface MainViewController : UIViewController <UIScrollViewDelegate, UITextFieldDelegate> {
    IBOutlet MyScrollView*  m_scrollView;
    IBOutlet UIView* m_viewPage1;
    IBOutlet UIView* m_viewPage2;
    IBOutlet UIView* m_viewPage3;
    IBOutlet UIView* m_viewPage4;
    IBOutlet UIView* m_viewPage5;
    IBOutlet UIView* m_viewPage9_5;
    IBOutlet UIView* m_viewPage6;
    IBOutlet UIView* m_viewPage7;
    IBOutlet UIView* m_viewPage4_5;
    IBOutlet UIView* m_viewPage9;
    IBOutlet UIView* m_viewPage10;
    
    UIImageView* m_imgShowingView;
    UIImageView* m_imgMovingView;
    int     m_nImageIndex;
    UITextField*    m_textField;
    

    IBOutlet UITextField *lblPrefixPhonenumber;

    IBOutlet UITextField *txtName;

    IBOutlet UITextField *txtAddress1;
    IBOutlet UITextField *txtAddress2;
    IBOutlet UITextField *txtCity;
    IBOutlet UITextField *txtState;
    IBOutlet UITextField *txtZip;
    IBOutlet UITextField *txtPhoneNumber;
    IBOutlet UITextField *txtUserName;
    IBOutlet UIButton *btnNext;//Page One Touch
    
    IBOutlet UIActivityIndicatorView *av;
}


- (void) initScrollView;

- (void) changePage;

- (void) animSlideShow:(BOOL)left2Right;
-(IBAction)nextFromOneTouchPage:(id)sender;//go  to Next from one touch  page
@end
