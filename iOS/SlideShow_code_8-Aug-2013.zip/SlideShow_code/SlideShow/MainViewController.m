//
//  MainViewController.m
//  SlideShow
//
//  Created by Apple on 13-5-30.
//  Copyright (c) 2013年 Apple. All rights reserved.
//

#import "MainViewController.h"
#import "JSON.h"

@interface MainViewController ()

@end

@implementation MainViewController

//#define IMAGE_COUNT     6

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
//    CGSize size = [UIScreen mainScreen].bounds.size;
//    m_imgShowingView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height-20)];
//    [m_imgShowingView setImage:[UIImage imageNamed:@"thenird01.png"]];
//    [self.view addSubview:m_imgShowingView];
       
    

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    // register for keyboard notifications
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWillShow)
//                                                 name:UIKeyboardWillShowNotification
//                                               object:nil];
//    
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWillHide)
//                                                 name:UIKeyboardWillHideNotification
//                                               object:nil];
    [self initScrollView];
    m_nImageIndex = 0;
}

- (void)viewWillDisappear:(BOOL)animated
{
    // unregister for keyboard notifications while not visible.
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
}

- (void) initScrollView {
    m_scrollView.pagingEnabled = YES;
    CGFloat x = 0, y = 0;
    NSArray* array = [NSArray arrayWithObjects:m_viewPage1, m_viewPage2, m_viewPage3, m_viewPage4, m_viewPage9_5, m_viewPage5, m_viewPage6, m_viewPage7, m_viewPage4_5, m_viewPage9, m_viewPage10, nil];
//    NSArray* arrayBg = [NSArray arrayWithObjects:@"1", @"2", @"3", @"4", @"5", @"10", @"6", @"7", @"4", @"8", @"11", nil];
    CGSize size = m_scrollView.frame.size;
    CGSize sizeScreen = [UIScreen mainScreen].bounds.size;
    for (int i = 0; i < [array count]; i ++) {
        UIView* view = [array objectAtIndex:i];
        [view setFrame:CGRectMake(x, y, size.width, size.height)];
        [m_scrollView addSubview:view];
        x += size.width;
    }
    
    m_scrollView.contentSize = CGSizeMake(x, sizeScreen.height-20);
    
    return;
    CGFloat width = 1, height = 68;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        height = 128;
    }
    else if (IS_IPHONE_5 == NO) {
        height -= 10;
    }
    for (int i = 0; i < [array count]; i ++) {
        x = size.width*(i+1);
        UIImageView* imgSlicedBg = [[UIImageView alloc] initWithFrame:CGRectMake(x, 0, width, size.height)];
        [imgSlicedBg setImage:[UIImage imageNamed:@"bg2_sliced.png"]];
        [m_scrollView addSubview:imgSlicedBg];
        [imgSlicedBg release];
        
        UIImageView* imgSlicedTop = [[UIImageView alloc] initWithFrame:CGRectMake(x, 0, width, height)];
        [imgSlicedTop setImage:[UIImage imageNamed:@"top_bg_sliced.png"]];
        [m_scrollView addSubview:imgSlicedTop];
        [imgSlicedTop release];
    }
   
    
}

#pragma mark - Flipside View Controller

- (void)dealloc
{
    [super dealloc];
}

- (void) keyboardWillShow
{
    
}
- (void) keyboardWillHide {
    
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self animSlideShow:NO];
}
- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touchend");
}
- (void) changePage {
    
}
- (void) animSlideShow:(BOOL)left2Right
{
    self.view.userInteractionEnabled = NO;
    CGSize size = [UIScreen mainScreen].bounds.size;
    size.height -= 20;
    CGRect rtMove;
    CGPoint center;
    if (left2Right) {
        m_nImageIndex = (m_nImageIndex - 1)%PAGE_COUNT;
        rtMove = CGRectMake(-size.width, 0, size.width, size.height);
        center = CGPointMake(size.width*3/2, size.height/2);
    }
    else {
        m_nImageIndex = (m_nImageIndex + 1)%PAGE_COUNT;
        rtMove = CGRectMake(size.width, 0, size.width, size.height);
        center = CGPointMake(-size.width/2, size.height/2);
    }
    NSString* strImg = [NSString stringWithFormat:@"thenird%02d.png", m_nImageIndex+1];
    m_imgMovingView = [[UIImageView alloc] initWithFrame:rtMove];
    [m_imgMovingView setImage:[UIImage imageNamed:strImg]];
    [self.view addSubview:m_imgMovingView];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:0.6];
    [UIView setAnimationDidStopSelector:@selector(didStopAnim)];
    m_imgShowingView.center = center;
    m_imgMovingView.center = CGPointMake(size.width/2, size.height/2);
    [UIView commitAnimations];
}

- (void) didStopAnim {
    self.view.userInteractionEnabled = YES;
    [m_imgShowingView removeFromSuperview];
    [m_imgShowingView release];
    m_imgShowingView = m_imgMovingView;
    m_imgMovingView = nil;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (m_textField) {
        [m_textField resignFirstResponder];
        m_textField = nil;
    }
//    NSLog(@"scrollViewDidScroll");
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
//    NSLog(@"scrollViewDidEndScrollingAnimation");
    int page = scrollView.contentOffset.x / scrollView.frame.size.width;
    m_nImageIndex = page;
}
#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    m_textField = textField;
    m_scrollView.frame=CGRectMake(m_scrollView.frame.origin.x,m_scrollView.frame.origin.y-100,m_scrollView.frame.size.width,m_scrollView.frame.size.height);
    return YES;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
 
    if (textField.tag == 955 && textField.text.length == 5 && string.length != 0)
    {
        textField.text = [NSString stringWithFormat:@"%@-",textField.text];
    }
   if (textField.tag == 100 && txtPhoneNumber.text.length+string.length != 0)
   {
       lblPrefixPhonenumber.hidden=false;
   }
   else
   {
       lblPrefixPhonenumber.hidden=TRUE;
   }
    if (textField.tag == 100 )
    {
        if([string isEqualToString:@"0"] || [string isEqualToString:@"1"] || [string isEqualToString:@"2"] || [string isEqualToString:@"3"] || [string isEqualToString:@"4"]  || [string isEqualToString:@"5"] || [string isEqualToString:@"6"] || [string isEqualToString:@"7"] || [string isEqualToString:@"8"] || [string isEqualToString:@"9"] || string.length==0 )
          return TRUE;
        else
            return FALSE;
    }
    return YES;
}



- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (m_textField == textField)
        m_textField = nil;
    
    m_scrollView.frame=CGRectMake(m_scrollView.frame.origin.x,m_scrollView.frame.origin.y+100,m_scrollView.frame.size.width,m_scrollView.frame.size.height);
    
    if ([[txtPhoneNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0 && [[txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0)
    {
        
        btnNext.alpha=0.2f;
    }
    

}
-(void)lightUpNextButton
{
//    [UIView beginAnimations:@"1" context:self];
//    [UIView setAnimationDuration:2];
//    btnNext.alpha=0;
//    [UIView commitAnimations];
//    [UIView beginAnimations:@"2" context:self];
//    
//    [UIView setAnimationDuration:2];
//    btnNext.alpha=1;
//    [UIView commitAnimations];

    [UIView animateWithDuration:1 delay:1 options:UIViewAnimationCurveEaseIn animations:
     ^{
         btnNext.alpha=1;

     }
                     completion:nil];
    
    //    [UIView setAnimationDuration:2];
//    [UIView commitAnimations];
//   
//    [UIView beginAnimations:@"4" context:self];
//    [UIView setAnimationDuration:2];
//    btnNext.alpha=1;
//    [UIView commitAnimations];
    
}
-(void)ApiCall
{
    NSString *str=[NSString stringWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://payfone.snkpk.com/test/php2js/linxauth.php?msisdn=%@&requestID=1linx_236468",txtPhoneNumber.text]] encoding:NSUTF8StringEncoding error:nil];

    NSLog(@"first :%@",[txtPhoneNumber.text substringToIndex:1]);
    
    if ([[txtPhoneNumber.text substringToIndex:1] intValue] != 1) {
     str=[NSString stringWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://payfone.snkpk.com/test/php2js/linxauth.php?msisdn=1%@&requestID=1linx_236468",txtPhoneNumber.text]] encoding:NSUTF8StringEncoding error:nil];
    }

   // NSString *str=[NSString stringWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://payfone.snkpk.com/test/php2js/linxauth.php?msisdn=1%@&requestID=1linx_236468",txtPhoneNumber.text]] encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"REsponse %@",str);
    str=[str stringByReplacingOccurrencesOfString:@"jsonpcallback('" withString:@""];
    str=[str stringByReplacingOccurrencesOfString:@"')" withString:@""];

    [av stopAnimating];
    
    NSMutableDictionary *dict=[[NSMutableDictionary alloc] init];
    dict=[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"];
   
    NSLog(@"array %@",dict);
    if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusDescription"]isEqualToString:@"Success"])
    {
        NSString *strAddr1,*strAddr2,*strCity,*strZip,*strState,*strname=@"";
        
        txtName.text=@"";
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        
        strname = [NSString stringWithFormat:@"%@ %@",[[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"] valueForKey:@"firstname"],[[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"] valueForKey:@"lastname"]];
      
        strAddr1 = [dict valueForKey:@"address1"];
        strAddr2 =[dict valueForKey:@"address2"]; //[[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"] valueForKey:@"address2"];
        strCity = [dict valueForKey:@"city"];//[[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"] valueForKey:@"city"];
        strZip = [dict valueForKey:@"zip"];//[[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"] valueForKey:@"zip"];
        strState =[dict valueForKey:@"state_province"]; //[[[[str JSONValue] valueForKey:@"Response"] valueForKey:@"Contact"] valueForKey:@"state_province"];
        

        if (![strname isKindOfClass:[NSNull class]])
        {
            txtName.text = strname;
        }

        if (![strAddr1 isKindOfClass:[NSNull class]])
        {
            txtAddress1.text = strAddr1;
        }

        if (![strAddr2 isKindOfClass:[NSNull class]])
        {
            txtAddress2.text = strAddr2;
        }
        if (![strCity isKindOfClass:[NSNull class]])
        {
            txtCity.text = strCity;
        }
        if (![strState isKindOfClass:[NSNull class]])
        {
            txtState.text = strState;
        }
        if (![strZip isKindOfClass:[NSNull class]])
        {
            
            if(strZip.length <= 5)
            {
                txtZip.text = strZip;
            }
            else
            {
                txtZip.text = [NSString stringWithFormat:@"%@-%@",[strZip substringToIndex:5],[strZip substringFromIndex:5]];
            }
            
            
        }
        [self lightUpNextButton];
        
    }
    
    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==302)
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"We don't yet have data for that mobile number provider. Please try another number." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";
        
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }

    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==301)
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"We couldn't find data for that number. Please try another number." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";
        
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }
    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==120 ||[[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==122)
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"There was an error. Please try again." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";
        
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }

    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==112)
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"Something is wrong with the number you entered. Please re-enter your number and try again." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";
        
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }
    
    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==110)
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"Please re-enter your mobile number and try again." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";
        
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }

    
    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusCode"] intValue] ==103)
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"Something went wrong on our side. Please try again." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";
        
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }

    else  if ([[[[str JSONValue] valueForKey:@"Response"]valueForKey:@"StatusDescription"]isEqualToString:@"Bad Parameter Invalid MSISDN"])
        
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"Please Enter Valid Phone Number" delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";

        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        return;
    }
  
    else
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Payfone" message:@"API successfully pinged. Response limit reached for 24-hour period." delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        
        txtName.text=@"";
        txtAddress1.text=@"";
        txtAddress2.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";
        
        return;
    }

}

-(IBAction)CallApi:(UITextField *)tf
{
    [tf resignFirstResponder];
    [av startAnimating];
    if ([[tf.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]==0)
    {
        UIAlertView *al=[[UIAlertView alloc]initWithTitle:@"Sorry" message:@"Please Enter Phone Number" delegate:nil cancelButtonTitle:@"Dissmiss" otherButtonTitles:nil];
        [al show];
        txtName.text=@"";

        txtAddress1.text=@"";
        txtAddress2.text=@"";
                txtCity.text=@"";
        txtState.text=@"";
        txtZip.text=@"";

        return;
    }
    
    [self performSelector:@selector(ApiCall) withObject:nil afterDelay:0.5];
    
}

-(IBAction)nextFromOneTouchPage:(id)sender;//go  to Next from one touch  page
{
    
    
    if ([[txtPhoneNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0 && [[txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0)
    {
        
        return;
    }
    m_scrollView.contentOffset=CGPointMake(m_viewPage9_5.frame.origin.x,m_scrollView.contentOffset.y);

}
@end
