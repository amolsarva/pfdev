//
//  MyScrollView.m
//  JigsawPuzzle
//
//  Created by Apple on 13-3-23.
//  Copyright (c) 2013年 Apple. All rights reserved.
//

#import "MyScrollView.h"

@implementation MyScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
//        self.delaysContentTouches			= NO;
//        self.canCancelContentTouches	= YES;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (BOOL)touchesShouldCancelInContentView:(UIView *)view{
	return NO;
}
//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    UITouch* touch = [touches anyObject];
//    
//    // One tap, forward
//    if(touch.tapCount == 1){
//        // for each subview
//        for(UIView* overlayView in self.subviews){
//            // Forward to my subclasss only
//            if([overlayView isKindOfClass:[PieceView class]]){
//                // translate coordinate
//                CGPoint newPoint = [touch locationInView:overlayView];
//                //NSLog(@"%@",NSStringFromCGPoint(newPoint));
//                
//                BOOL isInside = [overlayView pointInside:newPoint withEvent:event];
//                //if subview is hit
//                if(isInside){
//                    [overlayView touchesBegan:touches withEvent:event];
//                    break;
//                }
//            }
//        }
//        
//    }
////    [super touchesBegan:touches withEvent:event];
//}
//
//-(BOOL) touchesShouldBegin:(NSSet *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view {
//    UITouch* touch = [touches anyObject];
//    
//    // One tap, forward
//    if(touch.tapCount == 1){
//        // for each subview
//        for(UIView* overlayView in self.subviews){
//            // Forward to my subclasss only
//            if([overlayView isKindOfClass:[PieceView class]]){
//                // translate coordinate
//                CGPoint newPoint = [touch locationInView:overlayView];
//                //NSLog(@"%@",NSStringFromCGPoint(newPoint));
//                
//                BOOL isInside = [overlayView pointInside:newPoint withEvent:event];
//                //if subview is hit
//                if(isInside){
//                    [overlayView touchesBegan:touches withEvent:event];
//                    return NO;
//                }
//            }
//        }
//        
//    }
//    return YES;
//}
//-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
////	if (!self.dragging)
////    {
////        [[self nextResponder] touchesMoved:touches withEvent:event];
////    }
//    UITouch* touch = [touches anyObject];
//    
//    // One tap, forward
//    if(touch.tapCount == 1){
//        // for each subview
//        for(UIView* overlayView in self.subviews){
//            // Forward to my subclasss only
//            if([overlayView isKindOfClass:[PieceView class]]){
//                // translate coordinate
//                CGPoint newPoint = [touch locationInView:overlayView];
//                //NSLog(@"%@",NSStringFromCGPoint(newPoint));
//                
//                BOOL isInside = [overlayView pointInside:newPoint withEvent:event];
//                //if subview is hit
//                if(isInside){
//                    self.scrollEnabled = NO;
//                    [overlayView touchesMoved:touches withEvent:event];
//                    return;
//                }
//            }
//        }
//        
//    }
////    [super touchesMoved:touches withEvent:event];
//}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
//    UITouch* touch = [touches anyObject];
    
    // One tap, forward
//    if(touch.tapCount == 1){
//        // for each subview
//        for(UIView* overlayView in self.subviews){
//            // Forward to my subclasss only
//            if([overlayView isKindOfClass:[PieceView class]]){
//                // translate coordinate
//                CGPoint newPoint = [touch locationInView:overlayView];
//                //NSLog(@"%@",NSStringFromCGPoint(newPoint));
//                
//                BOOL isInside = [overlayView pointInside:newPoint withEvent:event];
//                //if subview is hit
//                if(isInside){
//                    [overlayView touchesEnded:touches withEvent:event];
//                    break;
//                }
//            }
//        }
//        
//    }
//	[super touchesEnded: touches withEvent: event];
    if(![self isDragging])
    {
//        [super touchesEnded:touches withEvent:event];
        CGPoint pt = self.contentOffset;
        CGSize sizeContent = self.contentSize;
        CGSize sizeView = self.frame.size;
        if (pt.x >= sizeContent.width-sizeView.width)
            return;
        int nPage = pt.x/sizeView.width;
        nPage += 1;
        [self setContentOffset:CGPointMake(sizeView.width*nPage, pt.y) animated:YES];
    }
}
//
//
//// Finds the UIViewController associated with the view, hopefully
//- (UIViewController*)viewController:(UIView *)view {
//    for (UIView* next = view; next; next = next.superview) {
//        UIResponder* nextResponder = [next nextResponder];
//        if ([nextResponder isKindOfClass:[UIViewController class]]) {
//            return (UIViewController*)nextResponder;
//        }
//    }
//    return nil;
//}
//
//- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
//    for(UIView *subview in [self subviews]) {
//        CGPoint convPt = CGPointMake(point.x - subview.frame.origin.x, point.y - subview.frame.origin.y);
//        if([subview isKindOfClass:[PieceView class]] && [subview pointInside:convPt withEvent:event]) {
////            self.delaysContentTouches = NO;
//            [self setScrollEnabled:NO];
//            break;
////            return subview;
//        }
////        else
////            self.delaysContentTouches = YES;
//    }
//    return [super hitTest:point withEvent:event];
//}
@end
